// sethome実行部分に追記
double setCost = plugin.getConfig().getDouble("economy.sethome-cost");

if (SetHome.econ.getBalance(player) >= setCost) {
    SetHome.econ.withdrawPlayer(player, setCost);
    // ここでホームを保存する既存の処理
    player.sendMessage("§a" + setCost + "円でホームを設定しました。");
} else {
    player.sendMessage("§c設定費用が足りません。");
}

