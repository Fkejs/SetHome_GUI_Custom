package beeted.sethome;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class SetHome extends JavaPlugin {
    public static Economy econ = null;

    @Override
    public void onEnable() {
        // 経済機能のセットアップ
        if (!setupEconomy()) {
            getLogger().severe("Vaultが見つからないため、経済機能を無効にします。");
        }
        
        saveDefaultConfig();
        getCommand("sethome").setExecutor(new HomeCommandExecutor(this));
        // GUIを開くコマンドなどの登録（既存のコードに合わせて追加）
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) return false;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        econ = rsp.getProvider();
        return econ != null;
    }
}

