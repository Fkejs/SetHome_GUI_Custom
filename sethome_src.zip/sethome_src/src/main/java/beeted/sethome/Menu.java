package beeted.sethome;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.ArrayList;
import java.util.List;

public class Menu {
    private final SetHome plugin;

    public Menu(SetHome plugin) {
        this.plugin = plugin;
    }

    // アイテム（ボタン）を作る際の処理
    public ItemStack createHomeItem(String homeName) {
        ItemStack item = new ItemStack(org.bukkit.Material.BEACON);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§b" + homeName);

        // configからテレポート費用を取得して表示
        double cost = plugin.getConfig().getDouble("economy.teleport-cost", 100.0);
        List<String> lore = new ArrayList<>();
        lore.add("§7クリックしてテレポート");
        lore.add("§e費用: " + cost + "円"); // 金額表示の追加
        meta.setLore(lore);
        
        item.setItemMeta(meta);
        return item;
    }

    // クリックされた時の支払い処理
    public void handleTeleport(Player player) {
        double cost = plugin.getConfig().getDouble("economy.teleport-cost");

        if (SetHome.econ.getBalance(player) >= cost) {
            SetHome.econ.withdrawPlayer(player, cost);
            player.sendMessage("§a" + cost + "円支払って移動しました。");
            // ここで実際のテレポートを実行
        } else {
            player.sendMessage("§cお金が足りません！ (必要: " + cost + "円)");
        }
    }
}

